# PronoX

App web (instalable en Android) con picks, probabilidades, combinadas y soñadoras para fútbol, NBA, MLB, NFL y NHL. Marcadores en vivo cada 30 s. No necesita llaves de API.

## Subirla a Vercel
1. Crea un repo en GitHub y sube todo el contenido de esta carpeta.
2. En vercel.com: Add New > Project > importa el repo > Deploy (sin configurar nada).
3. Abre la URL en Chrome del celular > menú > "Agregar a pantalla de inicio".

## Probar en tu PC
`npx vercel dev` y abre http://localhost:3000

## Cómo calcula
- Fuente: ESPN (API pública no oficial): marcadores, momios y récords.
- Con momios: quita el margen de la casa y obtiene la probabilidad de cada resultado.
- Fútbol: del total de goles y la ventaja de cada equipo deduce los goles esperados y calcula con Poisson los demás mercados (doble oportunidad, más/menos, ambos anotan, empate no apuesta).
- Sin momios: usa récords de temporada.
- Combinadas y soñadoras: un pick por partido; la probabilidad combinada es el producto de las probabilidades.

## extras/futbol-profundo
Análisis a fondo de fútbol con API-Football (xG proxy, forma, bajas, descanso, motivación, H2H, clima con Open-Meteo). Requiere la variable API_FOOTBALL_KEY. Aún no está conectado a la app.
